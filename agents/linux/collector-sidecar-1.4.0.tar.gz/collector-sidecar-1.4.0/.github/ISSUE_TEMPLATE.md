### Problem description

### Steps to reproduce the problem

1. ...

### Environment

* Sidecar Version:
* Graylog Version:
* Operating System:
* Elasticsearch Version:
* MongoDB Version:
